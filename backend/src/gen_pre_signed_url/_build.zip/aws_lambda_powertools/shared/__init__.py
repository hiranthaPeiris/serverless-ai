"""Internal shared functions. Do not rely on it besides internal usage."""
